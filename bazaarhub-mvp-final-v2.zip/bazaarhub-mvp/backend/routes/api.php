<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\ListingController;

Route::prefix('v1')->group(function () {
    Route::get('/health', fn () => response()->json(['ok'=>true,'service'=>'marketplace-api','version'=>'1.0']));
    Route::get('/listings', [ListingController::class,'index']);
    Route::get('/listings/{listing}', [ListingController::class,'show']);
    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/listings', [ListingController::class,'store']);
        Route::match(['put','patch'], '/listings/{listing}', [ListingController::class,'update']);
        Route::delete('/listings/{listing}', [ListingController::class,'destroy']);
    });
});
