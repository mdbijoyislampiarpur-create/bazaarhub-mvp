<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreListingRequest extends FormRequest
{
    public function authorize(): bool { return $this->user()?->role === 'seller' || $this->user()?->role === 'admin'; }
    public function rules(): array
    {
        return [
            'category_id'=>'required|uuid', 'city'=>'required|string|max:120', 'country_code'=>'required|string|size:2',
            'price_minor'=>'required|integer|min:0', 'currency'=>'required|in:BDT,USD,RUB,KGS',
            'condition'=>'required|in:new,used,refurbished', 'status'=>'sometimes|in:draft,pending',
        ];
    }
}
