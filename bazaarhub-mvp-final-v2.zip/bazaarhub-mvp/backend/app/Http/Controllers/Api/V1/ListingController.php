<?php
namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreListingRequest;
use App\Models\Listing;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $q = Listing::query()->where('status', 'published')->with(['translations','images']);
        if ($request->filled('category_id')) $q->where('category_id', $request->string('category_id'));
        if ($request->filled('city')) $q->where('city', $request->string('city'));
        if ($request->filled('currency')) $q->where('currency', $request->string('currency'));
        if ($request->filled('min_price')) $q->where('price_minor', '>=', (int)$request->input('min_price'));
        if ($request->filled('max_price')) $q->where('price_minor', '<=', (int)$request->input('max_price'));
        return response()->json($q->latest()->paginate(24));
    }

    public function store(StoreListingRequest $request): JsonResponse
    {
        $data = $request->validated();
        $data['seller_id'] = $request->user()->id;
        $listing = Listing::create($data);
        return response()->json($listing->load(['translations','images']), 201);
    }

    public function show(Listing $listing): JsonResponse
    {
        return response()->json($listing->load(['translations','images','seller']));
    }

    public function update(StoreListingRequest $request, Listing $listing): JsonResponse
    {
        abort_unless($request->user()->id === $listing->seller_id || $request->user()->role === 'admin', 403);
        $listing->update($request->validated());
        return response()->json($listing->fresh()->load(['translations','images']));
    }

    public function destroy(Request $request, Listing $listing): JsonResponse
    {
        abort_unless($request->user()->id === $listing->seller_id || $request->user()->role === 'admin', 403);
        $listing->delete();
        return response()->json(['deleted' => true]);
    }
}
