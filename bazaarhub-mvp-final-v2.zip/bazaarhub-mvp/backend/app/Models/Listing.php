<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
class Listing extends Model {use HasUuids; protected $fillable=['seller_id','category_id','city','country_code','price_minor','currency','condition','status']; public function translations(){return $this->hasMany(ListingTranslation::class);} public function images(){return $this->hasMany(ListingImage::class);} public function seller(){return $this->belongsTo(User::class,'seller_id');}}
