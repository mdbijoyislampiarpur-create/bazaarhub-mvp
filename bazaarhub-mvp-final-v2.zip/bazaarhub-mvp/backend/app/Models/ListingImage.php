<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model; class ListingImage extends Model {public $timestamps=false; protected $fillable=['listing_id','url','sort_order'];}
