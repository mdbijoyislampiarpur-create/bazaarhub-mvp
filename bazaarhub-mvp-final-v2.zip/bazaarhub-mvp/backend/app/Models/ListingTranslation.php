<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model; class ListingTranslation extends Model {public $timestamps=false; protected $fillable=['listing_id','locale','title','description'];}
