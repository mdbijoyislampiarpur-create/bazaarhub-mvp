<?php
namespace App\Models; use Illuminate\Foundation\Auth\User as Authenticatable; use Illuminate\Database\Eloquent\Concerns\HasUuids; class User extends Authenticatable {use HasUuids; protected $fillable=['name','email','phone','password','role','locale']; protected $hidden=['password','remember_token'];}
