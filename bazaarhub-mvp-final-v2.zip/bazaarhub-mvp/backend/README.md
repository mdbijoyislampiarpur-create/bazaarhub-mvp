# Backend

Laravel API.

Suggested API groups:
/api/v1/auth
/api/v1/categories
/api/v1/listings
/api/v1/sellers
/api/v1/orders
/api/v1/chat
/api/v1/payments
/api/v1/admin
