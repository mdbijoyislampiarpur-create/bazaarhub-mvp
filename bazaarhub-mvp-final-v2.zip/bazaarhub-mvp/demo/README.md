# BazaarHub browser demo

This is a dependency-free browser demo of the marketplace UX. Open `index.html` directly or serve the folder with any static HTTP server.

It demonstrates the four languages, four currencies, category browsing, filters, listing cards, seller posting UI, and account role cards. Production authentication, payments, chat, uploads, and persistence are wired through the Laravel/Next.js project separately.
