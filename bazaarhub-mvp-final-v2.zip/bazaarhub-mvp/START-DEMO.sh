#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/demo"
printf '\nBazaarHub demo: http://localhost:8080\n\n'
python3 -m http.server 8080
