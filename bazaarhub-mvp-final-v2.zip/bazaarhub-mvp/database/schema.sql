CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role VARCHAR(20) NOT NULL CHECK (role IN ('buyer','seller','admin')),
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(32) UNIQUE,
  password_hash TEXT,
  locale VARCHAR(5) NOT NULL DEFAULT 'en' CHECK (locale IN ('bn','en','ru','ky')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  slug VARCHAR(160) NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE category_translations (
  category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  locale VARCHAR(5) NOT NULL CHECK (locale IN ('bn','en','ru','ky')),
  name VARCHAR(160) NOT NULL,
  PRIMARY KEY (category_id, locale)
);

CREATE TABLE listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES categories(id),
  city VARCHAR(120) NOT NULL,
  country_code CHAR(2) NOT NULL,
  price_minor BIGINT NOT NULL CHECK (price_minor >= 0),
  currency CHAR(3) NOT NULL CHECK (currency IN ('BDT','USD','RUB','KGS')),
  condition VARCHAR(20) NOT NULL DEFAULT 'used' CHECK (condition IN ('new','used','refurbished')),
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('draft','pending','published','sold','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE listing_translations (
  listing_id UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  locale VARCHAR(5) NOT NULL CHECK (locale IN ('bn','en','ru','ky')),
  title VARCHAR(220) NOT NULL,
  description TEXT NOT NULL,
  PRIMARY KEY (listing_id, locale)
);

CREATE TABLE listing_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0
);

CREATE INDEX listings_search_idx ON listings(category_id, city, currency, status, price_minor);
CREATE INDEX listings_seller_idx ON listings(seller_id, status);
