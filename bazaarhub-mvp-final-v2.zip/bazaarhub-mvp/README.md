# BazaarHub MVP

A modern multilingual multi-vendor buying/selling marketplace foundation.

## Included now
- Responsive Next.js 15 frontend with Tailwind CSS
- Homepage, browse/search/filter, listing details
- Buyer account UI with Google/Facebook/Phone OTP entry points
- Seller dashboard and listing creation flow
- Admin moderation UI
- Bengali / English / Russian / Kyrgyz locale foundation
- BDT / USD / RUB / KGS currency model
- PostgreSQL schema for users, vendors, categories, listings, translations and images
- Laravel API controller/request foundation with listing CRUD, pagination and filters
- Redis + PostgreSQL Docker infrastructure

## Start infrastructure
```bash
cp .env.example .env
docker compose up -d
```

## Start frontend
```bash
cd frontend
npm install
npm run dev
```

## Laravel backend
The backend folder contains the Laravel application-specific models, request, controller and routes. Put these files into a Laravel 12 app, configure PostgreSQL/Redis and Sanctum, then run migrations.

### Next implementation
Authentication providers, real SMS OTP delivery, image storage, realtime chat, orders/commissions, and regional payment-provider adapters should be connected using the merchant credentials and current provider APIs for the deployment country.
