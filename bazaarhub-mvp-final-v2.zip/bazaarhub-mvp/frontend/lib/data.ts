export const listings=[
{id:'1',title:'iPhone 15 Pro 256GB',city:'Dhaka',price:105000,currency:'BDT',condition:'Used',category:'Electronics',image:'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=900&q=80'},
{id:'2',title:'MacBook Air M3',city:'Bishkek',price:1250,currency:'USD',condition:'New',category:'Computers',image:'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80'},
{id:'3',title:'Toyota Camry 2020',city:'Moscow',price:2850000,currency:'RUB',condition:'Used',category:'Vehicles',image:'https://images.unsplash.com/photo-1550355291-bbee04a92027?auto=format&fit=crop&w=900&q=80'},
{id:'4',title:'Samsung Galaxy S24',city:'Bishkek',price:78000,currency:'KGS',condition:'New',category:'Electronics',image:'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=900&q=80'}
];
