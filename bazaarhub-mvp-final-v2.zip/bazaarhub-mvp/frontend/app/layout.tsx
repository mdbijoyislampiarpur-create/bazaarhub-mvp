import './globals.css'; import Header from '../components/Header';
export const metadata={title:'BazaarHub — Buy & Sell Locally',description:'Multilingual multi-vendor marketplace'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body className="bg-slate-50 text-slate-950"><Header/>{children}<footer className="mt-20 border-t bg-white"><div className="mx-auto max-w-7xl px-5 py-10 text-sm text-slate-500">© 2026 BazaarHub · Buy · Sell · Connect</div></footer></body></html>}
