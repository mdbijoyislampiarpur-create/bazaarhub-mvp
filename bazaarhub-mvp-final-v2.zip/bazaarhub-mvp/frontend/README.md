# Frontend

Next.js App Router + TypeScript + Tailwind CSS.

Suggested routes:
/
/listings
/listings/[id]
/sell
/seller/dashboard
/account
/admin
